Snooze — Premium WhatsApp Bots
----------------------------------

Files:
- index.html        -> Main landing page (international generator + links)
- ai-tools.html     -> Client-side AI tools (demo)
- bot.html          -> Bot features & setup guide
- assets/logo.svg   -> Simple Snooze logo
- assets/favicon.svg-> Favicon

How to deploy (Vercel) from phone:
1. Create a GitHub repo (name: snooze) and upload all files preserving folders.
2. Login to vercel.com and "Import Project" from GitHub -> select repo -> Deploy.
3. Or use Netlify Drop: https://app.netlify.com/drop and upload the folder ZIP.

WhatsApp:
- Main Snooze number is embedded: +254799249888 (international format, no + in links)

If you want:
- I can create a ZIP file ready to upload (already provided in this package).
- I can also provide step-by-step screenshots tailored for Infinix phones.

Contact:
- Telegram: @baddie_szn
